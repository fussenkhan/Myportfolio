"use client"

import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { About } from "@/components/about"
import { Projects } from "@/components/projects"
import { RecentPosts } from "@/components/recent-posts"
import { Testimonials } from "@/components/testimonials"
import { ContactSection } from "@/components/contact-section"
import { FooterSimple } from "@/components/footer-simple"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      <Header />
      <main className="flex-1">
        <Hero />
        <About />
        <Projects />
        <RecentPosts />
        <Testimonials />
        <ContactSection />
      </main>
      <FooterSimple />
    </div>
  )
}
