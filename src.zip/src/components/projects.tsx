"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowRight, Github, ExternalLink } from "lucide-react"
import Link from "next/link"

const projects = [
  {
    title: "E-Learning Platform",
    description: "A comprehensive online learning platform built with React, Node.js, and MongoDB. Features include course management, video lessons, quizzes, and student progress tracking.",
    technologies: ["React", "Node.js", "Express", "MongoDB", "AWS S3", "Stripe"],
    image: "https://images.unsplash.com/photo-1501504905252-473c47e087f8?q=80&w=2074&auto=format&fit=crop",
    liveUrl: "#",
    githubUrl: "#",
    featured: true
  },
  {
    title: "Mobile Delivery App",
    description: "A Flutter-based delivery application for a food service company, featuring real-time tracking, payment integration, and order management. Deployed on both iOS and Android platforms.",
    technologies: ["Flutter", "Firebase", "Google Maps API", "Stripe", "Node.js"],
    image: "https://images.unsplash.com/photo-1565657867394-50c8a8268ae2?q=80&w=2069&auto=format&fit=crop",
    liveUrl: "#",
    githubUrl: "#",
    featured: true
  },
  {
    title: "Enterprise Dashboard System",
    description: "A comprehensive admin dashboard for enterprise resource management featuring data visualization, user management, and reporting capabilities.",
    technologies: ["Angular", "TypeScript", "Node.js", "PostgreSQL", "Docker", "Chart.js"],
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2426&auto=format&fit=crop",
    liveUrl: "#",
    githubUrl: "#",
    featured: true
  },
  {
    title: "Healthcare Management System",
    description: "A web-based healthcare management solution for clinics and small hospitals. Includes patient records, appointment scheduling, and inventory management.",
    technologies: ["React", "Express", "MongoDB", "Redux", "JWT", "Bootstrap"],
    image: "https://images.unsplash.com/photo-1584982751601-97dcc096659c?q=80&w=2072&auto=format&fit=crop",
    liveUrl: "#",
    githubUrl: "#",
    featured: false
  },
  {
    title: "Real Estate Listing Platform",
    description: "A property listing and management platform with advanced search, map integration, and agent/client portals.",
    technologies: ["Vue.js", "Laravel", "MySQL", "Google Maps", "AWS", "Redis"],
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?q=80&w=1973&auto=format&fit=crop",
    liveUrl: "#",
    githubUrl: "#",
    featured: false
  },
  {
    title: "Financial Portfolio Tracker",
    description: "A personal finance application that helps users track investments, expenses, and financial goals with data visualization and insights.",
    technologies: ["React Native", "Firebase", "Redux", "Chart.js", "Node.js", "Express"],
    image: "https://images.unsplash.com/photo-1565514020179-026bbd614757?q=80&w=2070&auto=format&fit=crop",
    liveUrl: "#",
    githubUrl: "#",
    featured: false
  }
]

export function ProjectCard({ project, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group"
    >
      <div className="overflow-hidden rounded-xl border border-border/50 bg-card/50 backdrop-blur-sm h-full transition-all duration-300 hover:shadow-lg">
        <div className="relative">
          <div className="aspect-video overflow-hidden">
            <img
              src={project.image}
              alt={project.title}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              crossOrigin="anonymous"
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-between p-4">
            <div className="flex gap-2">
              {project.githubUrl && (
                <Button size="icon" variant="secondary" asChild className="rounded-full" aria-label="View GitHub Repository">
                  <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                    <Github className="h-4 w-4" />
                  </a>
                </Button>
              )}
              {project.liveUrl && (
                <Button size="icon" variant="secondary" asChild className="rounded-full" aria-label="View Live Project">
                  <a href={project.liveUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </Button>
              )}
            </div>
          </div>
        </div>
        <div className="p-6">
          <h3 className="text-xl font-bold mb-2">{project.title}</h3>
          <p className="text-muted-foreground mb-4 line-clamp-3">{project.description}</p>
          <div className="flex flex-wrap gap-2 mb-4">
            {project.technologies.slice(0, 4).map((tech, i) => (
              <span key={i} className="inline-block px-2 py-1 text-xs rounded-full bg-muted text-muted-foreground">
                {tech}
              </span>
            ))}
            {project.technologies.length > 4 && (
              <span className="inline-block px-2 py-1 text-xs rounded-full bg-muted text-muted-foreground">
                +{project.technologies.length - 4} more
              </span>
            )}
          </div>
          <Button variant="ghost" size="sm" className="p-0 h-auto flex items-center gap-1 text-primary hover:text-primary/80 transition-colors">
            <span>View Details</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </motion.div>
  )
}

export function Projects() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.1 })

  const featuredProjects = projects.filter(project => project.featured)

  return (
    <section
      id="projects"
      ref={ref}
      className="py-16 md:py-24 scroll-mt-20"
    >
      <div className="container mx-auto px-4">
        <div>
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Projects</h2>
            <p className="text-muted-foreground text-lg">
              A selection of my recent development work
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProjects.map((project, index) => (
              <ProjectCard key={index} project={project} index={index} />
            ))}
          </div>

          <div className="mt-12 text-center">
            <Button asChild variant="outline" size="lg">
              <Link href="/projects">
                View All Projects
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
