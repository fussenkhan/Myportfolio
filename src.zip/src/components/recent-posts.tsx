"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Calendar } from "lucide-react"

// Sample recent blog posts data
const recentPosts = [
  {
    id: "mastering-flutter-development",
    title: "Mastering Flutter Development: Best Practices for 2025",
    date: "March 12, 2025",
    excerpt: "Learn advanced Flutter techniques and architecture patterns that I've used to build scalable, high-performance mobile applications.",
    image: "https://images.unsplash.com/photo-1551650975-87deedd944c3?q=80&w=1974&auto=format&fit=crop"
  },
  {
    id: "full-stack-development-approaches",
    title: "Modern Full-Stack Development: Frontend to Backend Integration",
    date: "March 10, 2025",
    excerpt: "Explore the most effective approaches to integrating React frontends with Node.js backends for seamless full-stack applications.",
    image: "https://images.unsplash.com/photo-1587620962725-abab7fe55159?q=80&w=1974&auto=format&fit=crop"
  },
  {
    id: "cloud-deployment-strategies",
    title: "Cloud Deployment Strategies for Web Applications",
    date: "March 5, 2025",
    excerpt: "A comprehensive guide to deploying your applications on cloud platforms with CI/CD pipelines for automated testing and delivery.",
    image: "https://images.unsplash.com/photo-1603695762547-fba8b92ba4eb?q=80&w=1974&auto=format&fit=crop"
  }
]

export function RecentPosts() {
  return (
    <section id="blog" className="py-16 md:py-24 bg-muted/30 scroll-mt-20">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Latest Articles</h2>
          <p className="text-muted-foreground text-lg">
            Thoughts, tutorials and insights on web and mobile development
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {recentPosts.map((post) => (
            <Card key={post.id} className="h-full flex flex-col">
              <div className="h-48 overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover"
                  crossOrigin="anonymous"
                />
              </div>
              <CardHeader>
                <div className="flex items-center text-xs text-muted-foreground mb-2">
                  <Calendar className="h-3 w-3 mr-1" />
                  <span>{post.date}</span>
                </div>
                <CardTitle className="line-clamp-2">{post.title}</CardTitle>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-muted-foreground line-clamp-3">{post.excerpt}</p>
              </CardContent>
              <CardFooter>
                <Button asChild variant="ghost" size="sm" className="p-0 h-auto">
                  <Link href={`/blog/${post.id}`}>
                    Read Article
                    <ArrowRight className="h-3.5 w-3.5 ml-2" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="flex justify-center">
          <Button asChild variant="outline" size="lg">
            <Link href="/blog">
              View All Articles
              <ArrowRight className="h-4 w-4 ml-2" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
