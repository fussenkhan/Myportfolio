"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight } from "lucide-react"
import { motion } from "framer-motion"
import { useRef } from "react"
import { useInView } from "framer-motion"

export function FeaturedPost() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  const featuredPost = {
    id: "mastering-react-hooks",
    title: "Mastering React Hooks: A Complete Guide",
    excerpt: "Learn how to use React's most powerful feature to write cleaner, more efficient components. This comprehensive guide covers all built-in hooks with practical examples.",
    date: "March 12, 2025",
    category: "Tutorials",
    image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=2070&auto=format&fit=crop",
    readTime: "15 min read",
    author: {
      name: "Your Name",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1887&auto=format&fit=crop"
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 10
      }
    }
  }

  return (
    <motion.section
      ref={ref}
      className="w-full"
      variants={containerVariants}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
    >
      <motion.div variants={itemVariants}>
        <h1 className="text-3xl md:text-4xl font-bold mb-8">Blog</h1>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-center">
        <motion.div
          className="lg:col-span-3 space-y-6"
          variants={itemVariants}
        >
          <Badge variant="secondary">{featuredPost.category}</Badge>
          <h2 className="text-2xl md:text-3xl font-bold">{featuredPost.title}</h2>
          <p className="text-muted-foreground text-lg">{featuredPost.excerpt}</p>

          <div className="flex items-center gap-3">
            <img
              src={featuredPost.author.avatar}
              alt={featuredPost.author.name}
              className="h-10 w-10 rounded-full object-cover"
              crossOrigin="anonymous"
            />
            <div className="flex flex-col">
              <span className="text-sm font-medium">{featuredPost.author.name}</span>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>{featuredPost.date}</span>
                <span>•</span>
                <span>{featuredPost.readTime}</span>
              </div>
            </div>
          </div>

          <motion.div
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
          >
            <Button asChild className="mt-2 group">
              <Link href={`/blog/${featuredPost.id}`}>
                Read Article
                <motion.span
                  className="ml-2 inline-block"
                  initial={{ x: 0 }}
                  whileHover={{ x: 5 }}
                  transition={{ type: "spring", stiffness: 400 }}
                >
                  <ArrowRight className="h-4 w-4" />
                </motion.span>
              </Link>
            </Button>
          </motion.div>
        </motion.div>

        <motion.div
          className="lg:col-span-2 overflow-hidden rounded-lg"
          variants={itemVariants}
          whileHover={{ scale: 1.02 }}
          transition={{ type: "spring", stiffness: 400 }}
        >
          <Link href={`/blog/${featuredPost.id}`}>
            <img
              src={featuredPost.image}
              alt={featuredPost.title}
              className="w-full h-[300px] object-cover transition-transform duration-500 hover:scale-105"
              crossOrigin="anonymous"
            />
          </Link>
        </motion.div>
      </div>

      <motion.div
        className="mt-12 border-b border-border"
        variants={itemVariants}
        initial={{ width: 0 }}
        animate={isInView ? { width: "100%" } : { width: 0 }}
        transition={{ duration: 1, delay: 0.5 }}
      />
    </motion.section>
  )
}
