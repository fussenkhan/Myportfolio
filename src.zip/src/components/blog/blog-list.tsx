"use client"

import { useState, useRef } from "react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { ArrowRight, Calendar, Clock, Tag } from "lucide-react"
import { motion } from "framer-motion"
import { useInView } from "framer-motion"

// Mock blog post data
const blogPosts = [
  {
    id: "building-responsive-layouts",
    title: "Building Responsive Layouts with CSS Grid and Flexbox",
    excerpt: "Learn how to create flexible, responsive layouts using modern CSS techniques that work across all devices.",
    date: "March 10, 2025",
    category: "Tutorials",
    image: "https://images.unsplash.com/photo-1587440871875-191322ee64b0?q=80&w=2071&auto=format&fit=crop",
    readTime: "10 min read",
  },
  {
    id: "javascript-promises",
    title: "Understanding JavaScript Promises and Async/Await",
    excerpt: "A deep dive into asynchronous JavaScript patterns and how to use them effectively in your applications.",
    date: "March 5, 2025",
    category: "Tutorials",
    image: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?q=80&w=2074&auto=format&fit=crop",
    readTime: "12 min read",
  },
  {
    id: "state-management",
    title: "State Management in Modern React Applications",
    excerpt: "Explore different approaches to managing state in React, from Context API to Redux and Zustand.",
    date: "February 28, 2025",
    category: "Articles",
    image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?q=80&w=2070&auto=format&fit=crop",
    readTime: "15 min read",
  },
  {
    id: "design-systems",
    title: "Building Design Systems for Consistent UI Development",
    excerpt: "Learn how to create and implement a design system that improves consistency and speeds up development.",
    date: "February 20, 2025",
    category: "Articles",
    image: "https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?q=80&w=2070&auto=format&fit=crop",
    readTime: "8 min read",
  },
  {
    id: "typescript-basics",
    title: "TypeScript Basics for JavaScript Developers",
    excerpt: "A beginner-friendly introduction to TypeScript that will help you write more robust JavaScript code.",
    date: "February 15, 2025",
    category: "Tutorials",
    image: "https://images.unsplash.com/photo-1629904853716-f0bc54eea481?q=80&w=2070&auto=format&fit=crop",
    readTime: "11 min read",
  },
]

export function BlogList() {
  const [activeFilter, setActiveFilter] = useState("All")
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.1 })

  const filteredPosts = activeFilter === "All"
    ? blogPosts
    : blogPosts.filter(post => post.category === activeFilter)

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 50,
        damping: 7
      }
    }
  }

  return (
    <motion.section
      ref={ref}
      className="w-full"
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      variants={containerVariants}
    >
      <motion.div variants={itemVariants}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8">
          <h2 className="text-2xl md:text-3xl font-bold">Latest Articles</h2>

          <div className="flex items-center gap-2 mt-4 md:mt-0">
            {["All", "Articles", "Tutorials"].map((filter) => (
              <Button
                key={filter}
                variant={activeFilter === filter ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveFilter(filter)}
              >
                {filter}
              </Button>
            ))}
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPosts.map((post, index) => (
          <BlogCard key={post.id} post={post} index={index} />
        ))}
      </div>

      <motion.div
        className="flex justify-center mt-12"
        variants={itemVariants}
      >
        <Button asChild variant="outline" className="group">
          <Link href="/blog/archive">
            View All Articles
            <motion.span
              className="ml-2 inline-block"
              initial={{ x: 0 }}
              whileHover={{ x: 5 }}
              transition={{ type: "spring", stiffness: 400 }}
            >
              <ArrowRight className="h-4 w-4" />
            </motion.span>
          </Link>
        </Button>
      </motion.div>
    </motion.section>
  )
}

function BlogCard({ post, index }) {
  const cardVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 50,
        damping: 10,
        delay: index * 0.1
      }
    }
  }

  return (
    <motion.div
      variants={cardVariants}
      whileHover={{ y: -8 }}
      transition={{ type: "spring", stiffness: 400 }}
    >
      <Card className="overflow-hidden h-full flex flex-col border border-border/50 bg-card/50 backdrop-blur-sm">
        <div className="relative h-48 overflow-hidden">
          <img
            src={post.image}
            alt={post.title}
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
            crossOrigin="anonymous"
          />
          <Badge
            variant="secondary"
            className="absolute top-4 right-4"
          >
            {post.category}
          </Badge>
        </div>

        <CardContent className="flex-grow pt-6 pb-2">
          <div className="flex items-center text-xs text-muted-foreground mb-3 gap-4">
            <div className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              <span>{post.date}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              <span>{post.readTime}</span>
            </div>
          </div>

          <Link href={`/blog/${post.id}`} className="hover:underline">
            <h3 className="text-xl font-semibold mb-2 line-clamp-2">{post.title}</h3>
          </Link>

          <p className="text-muted-foreground text-sm line-clamp-3">{post.excerpt}</p>
        </CardContent>

        <CardFooter className="pb-6">
          <Button asChild variant="ghost" size="sm" className="p-0 h-auto flex items-center gap-2 group">
            <Link href={`/blog/${post.id}`}>
              Read More
              <motion.span
                className="inline-block"
                initial={{ x: 0 }}
                whileHover={{ x: 5 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                <ArrowRight className="h-3 w-3" />
              </motion.span>
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  )
}
