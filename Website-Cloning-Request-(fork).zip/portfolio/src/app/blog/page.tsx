import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

// Blog posts data
const blogPosts = [
  {
    id: "mastering-react-hooks",
    title: "Mastering React Hooks: A Complete Guide",
    date: "March 12, 2025",
    excerpt: "Learn how to use React's most powerful feature to write cleaner, more efficient components.",
    image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=2070&auto=format&fit=crop"
  },
  {
    id: "building-responsive-layouts",
    title: "Building Responsive Layouts with CSS Grid and Flexbox",
    date: "March 10, 2025",
    excerpt: "Create flexible, responsive layouts using modern CSS techniques that work across all devices.",
    image: "https://images.unsplash.com/photo-1587440871875-191322ee64b0?q=80&w=2071&auto=format&fit=crop"
  },
  {
    id: "javascript-promises",
    title: "Understanding JavaScript Promises and Async/Await",
    date: "March 5, 2025",
    excerpt: "A deep dive into asynchronous JavaScript patterns and how to use them effectively in your applications.",
    image: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?q=80&w=2074&auto=format&fit=crop"
  }
]

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="bg-muted py-6">
        <div className="container mx-auto px-4">
          <Link href="/" className="text-xl font-bold">Portfolio</Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold mb-8">Blog</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogPosts.map(post => (
            <Card key={post.id} className="overflow-hidden">
              <div className="h-48 overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover"
                  crossOrigin="anonymous"
                />
              </div>
              <CardHeader>
                <div className="text-xs text-muted-foreground mb-2">
                  {post.date}
                </div>
                <CardTitle className="line-clamp-2">
                  <Link href={`/blog/${post.id}`} className="hover:underline">
                    {post.title}
                  </Link>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground line-clamp-3">{post.excerpt}</p>
                <Link
                  href={`/blog/${post.id}`}
                  className="inline-block mt-4 text-sm text-primary hover:underline"
                >
                  Read Article →
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}
