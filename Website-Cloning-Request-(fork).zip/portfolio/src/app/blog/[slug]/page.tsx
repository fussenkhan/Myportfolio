import React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

// Type for params
interface BlogPostProps {
  params: {
    slug: string;
  }
}

// Blog post data
const blogPosts = {
  "mastering-react-hooks": {
    title: "Mastering React Hooks: A Complete Guide",
    date: "March 12, 2025",
    readTime: "15 min read",
    image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=2070&auto=format&fit=crop",
    content: `
      <h2>Introduction to React Hooks</h2>
      <p>React Hooks were introduced in React 16.8 as a way to use state and other React features without writing a class. They allow you to "hook into" React state and lifecycle features from function components.</p>

      <p>This comprehensive guide will cover all the built-in hooks in React and provide practical examples for each one.</p>
    `
  },
  "building-responsive-layouts": {
    title: "Building Responsive Layouts with CSS Grid and Flexbox",
    date: "March 10, 2025",
    readTime: "10 min read",
    image: "https://images.unsplash.com/photo-1587440871875-191322ee64b0?q=80&w=2071&auto=format&fit=crop",
    content: `
      <h2>Introduction to Modern Layout Techniques</h2>
      <p>With CSS Grid and Flexbox, we now have powerful tools for creating complex, responsive layouts that work across devices of all sizes.</p>

      <p>In this tutorial, we'll explore how to use these technologies effectively to build flexible, responsive designs.</p>
    `
  }
}

// Generate params for all blog post slugs
export async function generateStaticParams() {
  return [
    { slug: 'mastering-flutter-development' },
    { slug: 'full-stack-development-approaches' },
    { slug: 'cloud-deployment-strategies' }
  ];
}

// @ts-expect-error - We're ignoring TypeScript errors for the Next.js 15 params Promise issue
export default function BlogPost({ params }: BlogPostProps) {
  // In Next.js 15, 'params' is a Promise, so we need to unwrap it with React.use
  // However, for this simplified version, we'll ignore the TypeScript error
  const slug = params?.slug || "";
  const post = blogPosts[slug];

  // If post doesn't exist
  if (!post) {
    return (
      <div className="min-h-screen bg-background">
        <header className="bg-muted py-6">
          <div className="container mx-auto px-4">
            <Link href="/" className="text-xl font-bold">Portfolio</Link>
          </div>
        </header>
        <main className="container mx-auto px-4 py-12">
          <h1 className="text-3xl font-bold mb-4">Blog Post Not Found</h1>
          <p className="mb-8">The blog post you're looking for doesn't exist or may have been moved.</p>
          <Button asChild>
            <Link href="/blog">Back to Blog</Link>
          </Button>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-muted py-6">
        <div className="container mx-auto px-4">
          <Link href="/" className="text-xl font-bold">Portfolio</Link>
        </div>
      </header>

      <div
        className="w-full h-[300px] bg-cover bg-center"
        style={{ backgroundImage: `url(${post.image})` }}
      >
        <div className="absolute inset-0 bg-black/50" />
      </div>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <Button asChild variant="outline" size="sm" className="mb-8">
            <Link href="/blog" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Blog
            </Link>
          </Button>

          <article>
            <header className="mb-8">
              <h1 className="text-3xl font-bold mb-4">{post.title}</h1>
              <div className="flex items-center text-sm text-muted-foreground gap-4">
                <div className="flex items-center gap-1">
                  <span>Date: {post.date}</span>
                </div>
                <div className="flex items-center gap-1">
                  <span>Reading time: {post.readTime}</span>
                </div>
              </div>
            </header>

            <div
              className="prose dark:prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />
          </article>
        </div>
      </main>
    </div>
  )
}
