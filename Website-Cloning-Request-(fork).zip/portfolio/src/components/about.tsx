"use client"

import { Button } from "@/components/ui/button"
import { motion, useInView } from "framer-motion"
import { useRef } from "react"
import {
  Laptop,
  Server,
  Smartphone,
  Code,
  Database,
  Users,
  Layout,
  ArrowRight
} from "lucide-react"

export function About() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 50,
        damping: 10
      }
    }
  }

  const skills = [
    {
      title: "Frontend Development",
      description: "Building responsive UIs with modern frameworks",
      icon: <Layout className="h-10 w-10 text-primary" />,
      technologies: ["React", "Angular", "Vue.js", "HTML5/CSS3", "JavaScript/TypeScript"]
    },
    {
      title: "Backend Development",
      description: "Creating robust server-side applications and APIs",
      icon: <Server className="h-10 w-10 text-primary" />,
      technologies: ["Node.js", "Express", "Django", "ASP.NET Core", "Spring Boot"]
    },
    {
      title: "Database Management",
      description: "Designing and optimizing database systems",
      icon: <Database className="h-10 w-10 text-primary" />,
      technologies: ["MongoDB", "PostgreSQL", "MySQL", "Firebase", "Redis"]
    },
    {
      title: "Mobile Development",
      description: "Creating native and cross-platform mobile apps",
      icon: <Smartphone className="h-10 w-10 text-primary" />,
      technologies: ["Flutter", "React Native", "Kotlin", "Swift", "Ionic"]
    },
    {
      title: "DevOps & Cloud",
      description: "Implementing CI/CD pipelines and cloud infrastructure",
      icon: <Laptop className="h-10 w-10 text-primary" />,
      technologies: ["Docker", "Kubernetes", "AWS", "Azure", "GitHub Actions"]
    },
    {
      title: "Collaboration & Project Management",
      description: "Working effectively in teams and managing projects",
      icon: <Users className="h-10 w-10 text-primary" />,
      technologies: ["Agile/Scrum", "Jira", "Git", "Trello", "Slack"]
    }
  ]

  return (
    <section
      id="about"
      ref={ref}
      className="py-16 md:py-24 scroll-mt-20"
    >
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16"
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          variants={containerVariants}
        >
          <motion.h2
            className="text-3xl md:text-4xl font-bold mb-4"
            variants={itemVariants}
          >
            About Me
          </motion.h2>
          <motion.p
            className="text-muted-foreground text-lg"
            variants={itemVariants}
          >
            I'm Abdul Hamid Alkozai, a Full-stack Developer with expertise in creating efficient,
            scalable, and user-friendly applications. With 5+ years of experience in software
            development, I specialize in building web and mobile solutions that solve real-world problems.
          </motion.p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto"
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          variants={containerVariants}
        >
          {skills.map((skill, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="group"
              whileHover={{ y: -5 }}
              transition={{ type: "spring", stiffness: 300, damping: 10 }}
            >
              <div className="bg-card/50 border border-border/50 rounded-lg p-6 h-full backdrop-blur-sm transition-all duration-300 hover:shadow-lg">
                <div className="mb-4">
                  {skill.icon}
                </div>
                <h3 className="text-xl font-bold mb-3">{skill.title}</h3>
                <p className="text-muted-foreground mb-4">{skill.description}</p>
                <div className="space-y-1">
                  <p className="text-sm font-medium">Technologies:</p>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    {skill.technologies.map((tech, i) => (
                      <li key={i} className="flex items-center">
                        <Code className="h-3 w-3 mr-2 text-primary" />
                        {tech}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          className="text-center mt-12"
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          variants={containerVariants}
        >
          <motion.div
            variants={itemVariants}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-block"
          >
            <Button asChild variant="outline" size="lg" className="group">
              <a href="#projects">
                View My Projects
                <motion.span
                  className="ml-2 inline-block"
                  initial={{ x: 0 }}
                  whileHover={{ x: 5 }}
                  transition={{ type: "spring", stiffness: 400 }}
                >
                  <ArrowRight className="h-4 w-4" />
                </motion.span>
              </a>
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
