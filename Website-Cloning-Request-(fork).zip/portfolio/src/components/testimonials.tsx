"use client"

import { useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { motion, useInView } from "framer-motion"
import { Quote } from "lucide-react"

// Sample testimonial data
const testimonials = [
  {
    id: 1,
    name: "Sarah Johnson",
    role: "Project Manager",
    company: "TechVision Inc.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1974&auto=format&fit=crop",
    quote: "Abdul developed our enterprise dashboard system with exceptional attention to detail. His full-stack expertise enabled him to deliver a comprehensive solution that has significantly improved our operational efficiency."
  },
  {
    id: 2,
    name: "Michael Chen",
    role: "CTO",
    company: "StartUp Innovate",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1974&auto=format&fit=crop",
    quote: "Abdul's work on our Flutter-based delivery app was outstanding. From API integration to responsive UI design, he delivered a polished product that has helped us scale our business across multiple regions."
  },
  {
    id: 3,
    name: "Jessica Martinez",
    role: "Director of E-Learning",
    company: "EduTech Solutions",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=1961&auto=format&fit=crop",
    quote: "We hired Abdul to develop our online learning platform. His comprehensive approach to both frontend and backend challenges resulted in a robust, user-friendly system that has received excellent feedback from our students."
  },
  {
    id: 4,
    name: "David Wilson",
    role: "Founder",
    company: "HealthTech Innovations",
    image: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?q=80&w=1974&auto=format&fit=crop",
    quote: "Abdul helped us create our healthcare management system from scratch. His technical expertise combined with his understanding of user needs produced an exceptional product that has streamlined our clinical operations."
  }
]

export function Testimonials() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 50,
        damping: 10
      }
    }
  }

  return (
    <section
      id="testimonials"
      ref={ref}
      className="py-16 md:py-24 bg-muted/30 scroll-mt-20"
    >
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-12"
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          variants={containerVariants}
        >
          <motion.h2
            className="text-3xl md:text-4xl font-bold mb-4"
            variants={itemVariants}
          >
            Client Testimonials
          </motion.h2>
          <motion.p
            className="text-muted-foreground text-lg"
            variants={itemVariants}
          >
            What clients say about my work and collaboration
          </motion.p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              variants={itemVariants}
              className={index === testimonials.length - 1 && testimonials.length % 2 !== 0 ? "md:col-span-2" : ""}
            >
              <Card className="h-full overflow-hidden border border-border/50 bg-card/50 backdrop-blur-sm relative">
                <CardContent className="pt-6 pb-6">
                  <div className="absolute top-6 right-6 text-primary/20">
                    <Quote className="h-12 w-12" />
                  </div>

                  <div className="text-lg mb-4 relative z-10">
                    "{testimonial.quote}"
                  </div>

                  <div className="flex items-center mt-6">
                    <div className="h-12 w-12 rounded-full overflow-hidden mr-4 border border-border">
                      <img
                        src={testimonial.image}
                        alt={testimonial.name}
                        className="h-full w-full object-cover"
                        crossOrigin="anonymous"
                      />
                    </div>
                    <div>
                      <div className="font-medium">{testimonial.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {testimonial.role}, {testimonial.company}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
