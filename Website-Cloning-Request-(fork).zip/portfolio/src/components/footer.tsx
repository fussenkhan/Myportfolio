"use client"

import Link from "next/link"
import { Github, Linkedin, Twitter, Instagram, ArrowUp } from "lucide-react"
import { motion } from "framer-motion"

export function Footer() {
  const currentYear = new Date().getFullYear()

  const socialLinks = [
    { name: "GitHub", icon: <Github className="h-5 w-5" />, url: "https://github.com/yourusername" },
    { name: "LinkedIn", icon: <Linkedin className="h-5 w-5" />, url: "https://linkedin.com/in/yourusername" },
    { name: "Twitter", icon: <Twitter className="h-5 w-5" />, url: "https://twitter.com/yourusername" },
    { name: "Instagram", icon: <Instagram className="h-5 w-5" />, url: "https://instagram.com/yourusername" },
  ]

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: "spring", stiffness: 50, damping: 10 }
    }
  }

  return (
    <motion.footer
      className="border-t border-border/40 bg-muted/20 py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <div className="container mx-auto px-4">
        <motion.div
          className="flex flex-col md:flex-row justify-between items-center gap-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div
            variants={itemVariants}
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <Link href="/" className="font-bold text-xl">
                Portfolio
              </Link>
            </motion.div>
            <motion.p
              className="text-muted-foreground text-sm mt-2"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
            >
              Crafting beautiful web experiences
            </motion.p>
          </motion.div>

          <motion.div
            className="flex items-center gap-6"
            variants={containerVariants}
          >
            {socialLinks.map((link, index) => (
              <motion.a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={link.name}
                className="text-muted-foreground hover:text-foreground transition-colors"
                variants={itemVariants}
                whileHover={{
                  scale: 1.2,
                  rotate: [0, 5, -5, 0],
                  transition: { duration: 0.5 }
                }}
                whileTap={{ scale: 0.9 }}
              >
                {link.icon}
                <span className="sr-only">{link.name}</span>
              </motion.a>
            ))}
          </motion.div>

          <motion.div
            className="flex flex-col items-end"
            variants={itemVariants}
          >
            <motion.button
              onClick={scrollToTop}
              aria-label="Scroll to top"
              className="inline-flex items-center justify-center h-8 w-8 rounded-md border border-border/50 bg-background/50 hover:bg-background/80 transition-colors mb-4"
              whileHover={{
                y: -5,
                transition: { type: "spring", stiffness: 400, damping: 10 }
              }}
              whileTap={{ scale: 0.9 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{
                opacity: 1,
                y: 0,
                transition: { delay: 0.5, duration: 0.5 }
              }}
            >
              <motion.div
                animate={{
                  y: [0, -3, 0],
                }}
                transition={{
                  repeat: Infinity,
                  duration: 1.5,
                  ease: "easeInOut"
                }}
              >
                <ArrowUp className="h-4 w-4" />
              </motion.div>
            </motion.button>
            <motion.p
              className="text-muted-foreground text-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.5 }}
            >
              &copy; {currentYear} Your Name. All rights reserved.
            </motion.p>
          </motion.div>
        </motion.div>
      </div>
    </motion.footer>
  )
}
