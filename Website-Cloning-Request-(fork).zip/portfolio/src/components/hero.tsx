"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowDown, Download, ExternalLink, Github } from "lucide-react"
import { motion } from "framer-motion"

export function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 10
      }
    }
  }

  return (
    <section className="relative overflow-hidden pt-24 pb-16 md:pt-32 md:pb-24">
      <motion.div
        className="absolute inset-0 bg-grid-small-black/[0.05] -z-10"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 0.2 }}
      />

      <motion.div
        className="absolute inset-0 flex items-center justify-center -z-10"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1, delay: 0.5 }}
      >
        <div className="bg-background/80 h-[500px] w-[500px] rounded-full blur-3xl" />
      </motion.div>

      <div className="container mx-auto px-4">
        <motion.div
          className="flex flex-col items-center text-center max-w-3xl mx-auto"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div variants={itemVariants}>
            <Badge className="mb-4">Available for Work</Badge>
          </motion.div>

          <motion.h1
            className="mb-6"
            variants={itemVariants}
          >
            <span className="text-primary">Full-stack Developer</span>{" "}
            Crafting Modern Web Experiences
          </motion.h1>

          <motion.p
            className="text-xl text-muted-foreground mb-8"
            variants={itemVariants}
          >
            I'm <span className="font-semibold">Abdul Hamid Alkozai</span>, a full-stack developer based in AFG/IND.
            I build responsive, user-centered applications with modern frameworks and clean code practices.
          </motion.p>

          <motion.div
            className="flex flex-wrap gap-4 justify-center mb-12"
            variants={itemVariants}
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button asChild size="lg" className="group">
                <a href="#contact">
                  Work with me
                  <motion.span
                    className="ml-2 inline-block"
                    initial={{ x: 0 }}
                    whileHover={{ x: 5 }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    <ExternalLink className="h-4 w-4" />
                  </motion.span>
                </a>
              </Button>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button asChild variant="outline" size="lg" className="group">
                <a href="https://github.com/ahamidalkozai" target="_blank" rel="noopener noreferrer">
                  GitHub
                  <motion.span
                    className="ml-2 inline-block"
                    initial={{ x: 0 }}
                    whileHover={{ x: 5 }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    <Github className="h-4 w-4" />
                  </motion.span>
                </a>
              </Button>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button asChild variant="secondary" size="lg" className="group">
                <a href="/resume.pdf" download="Abdul_Hamid_Alkozai_Resume.pdf">
                  Download CV
                  <motion.span
                    className="ml-2 inline-block"
                    initial={{ y: 0 }}
                    whileHover={{ y: -3 }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    <Download className="h-4 w-4" />
                  </motion.span>
                </a>
              </Button>
            </motion.div>
          </motion.div>

          <motion.div
            variants={itemVariants}
            animate={{
              y: [0, 10, 0],
            }}
            transition={{
              repeat: Infinity,
              duration: 2,
              ease: "easeInOut"
            }}
            className="mt-8 opacity-60"
          >
            <a href="#about" aria-label="Scroll to about section">
              <ArrowDown className="h-6 w-6" />
            </a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
